clear
alias R="rm -rf"
alias E="echo -e"
alias S="sleep"
alias SP="chmod"
alias T="touch
PKG=com.tencent.ig
Baqir (){
data=/data/media/0
Saved=$data/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
am force-stop $PKG
killall $PKG &> /dev/null
R /data/data/$PKG/databases
R $data/Android/data/$PKG/files/login-identifier.txt
R $data/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/{Intermediate,Content,*.bak}
R $Saved/SaveGames/{*.json,/*/*.json,/*/*/*.json,*.bak}
cd /data/data/$PKG
R shared_prefs
mkdir shared_prefs
SP 0771 /data/data/$PKG/shared_prefs
cd /data/data/$PKG/shared_prefs
E "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > device_id.xml
SP 0660 device_id.xml
E "
Completed successfully 🤝""